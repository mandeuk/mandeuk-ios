//
//  ContentView.swift
//  CleanMVVM
//
//  Created by Inho Lee on 6/2/25.
//

import SwiftUI
import Shared

struct ContentView: View {
//    let useCase = KoinHelper().resolve() as! GetRandomNumberUseCase
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
            Button(action: {
                
            }, label: {
                
            })
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
