//
//  CleanMVVMTests.swift
//  CleanMVVMTests
//
//  Created by Inho Lee on 6/2/25.
//

import Testing

struct CleanMVVMTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
